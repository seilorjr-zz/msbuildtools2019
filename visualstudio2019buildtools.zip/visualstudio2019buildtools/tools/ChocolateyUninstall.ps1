﻿Remove-VisualStudioProduct `
    -PackageName 'visualstudio2019buildtools' `
    -Product 'BuildTools' `
    -VisualStudioYear '2019' `
    -Preview $false
